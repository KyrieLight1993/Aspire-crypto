<?php
//ini_set("error_reporting",E_ALL & ~E_NOTICE);
session_start();
define("DBfile","sq##l.db");//数据库名字加#后访客就无法下载数据库了增加安全性
$webtitle="Aspire Crypto";//网站标题文字在这里改
$ndfpage='1';//这个方便开发的时候能看到CSS样式表的保留默认值即可
phpjc();

function phpjc(){//判断是否开启了SQLite3
if (extension_loaded('sqlite3')==false) { 
    echo '<div align="center"><br><b>Friendship tips:</b> Please turn on <b>sqlite3</b> first.<br><br><img src="imgs/sqlite3.gif" hspace="20" /></div>';exit;
} 
}
function NDF_dq($sql,$str)//SQL单条读取
{
$db = new SQLite3(DBfile);
//$db =new PDO('sqlite:english.db');
$stmt = $db->prepare($sql);
$result = $stmt->execute();
while ($row = $result->fetchArray())
{
return $row[$str];
}
}
function NDFdqs($sql)//SQL单条数组读取
{
$db = new SQLite3(DBfile);
//$db =new PDO('sqlite:english.db');
$stmt = $db->prepare($sql);
$result = $stmt->execute();
while ($row = $result->fetchArray())
{
return $row;
}
}
function NDFsql($sql){//SQL执行
$db = new SQLite3(DBfile);
/*CREATE table people (name varchar(20));
INSERT INTO people VALUES ("Émilie");*/
return @$db->exec($sql);
}
/*
$db = new SQLite3('english.db');
$stmt = $db->prepare("SELECT * FROM stardict WHERE word='".$word."' limit 10");

$result = $stmt->execute();

while ($row = $result->fetchArray())

{
echo $row['translation'] . PHP_EOL;

}
*/
function GetR($url,$filename){//远程下载图片
$c=file_get_contents($url);
  $fp = fopen($filename,'w');
fwrite($fp,$c);
   fclose($fp);
	return true;
}
function MD16($str)//MD5加密
{return substr(md5($str),8,16); }
function NDF_time()
{return gmdate("Y-m-d H:i:s",time()+0*3600);}//时区

function DisplayError($str)
{echo $str;} 

function NDF_get($str)
{
if($_GET[strtolower($str)]=="")
{return $_GET[strtoupper($str)];}
else
{return $_GET[strtolower($str)];}
}

function NDF_post($str)
{
if($_POST[strtolower($str)]=="")
{return $_POST[strtoupper($str)];}
else
{return $_POST[strtolower($str)];}
}
function NDFint($str)
{
if (is_numeric($str))
{return $str;}
else
{return 0;}
}
function get_url_content($url) {   
    if(extension_loaded('curl')) {   
        $ch = curl_init($url);   
        curl_setopt($ch, CURLOPT_HEADER, 0);   
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);   
        $content = curl_exec($ch);   
        curl_close($ch);   
    } else {   
        $content = file_get_contents($url);   
    }   
    !$content && die("ERROR:$url");   
    return $content;   
} 
function msg($str){//消息提示
echo "<script language=javascript>alert('".$str."');history.go(-1)</script>";exit;
}
function goback(){
header("location:".$_SERVER['HTTP_REFERER']);exit;
}
header("Content-type: text/html; charset=utf-8");
$user=@$_SESSION["user"];
function create(){//建立SQLite数据库
NDFsql("CREATE table users (user varchar(50),balance float DEFAULT '0',psw varchar(20))");
//NDFsql("CREATE table account (user varchar(50),balance float DEFAULT '0')");
NDFsql("CREATE table orderlist (user varchar(50),currency varchar(30),qty float DEFAULT '0',price float DEFAULT '0',times varchar(30))");
NDFsql("CREATE table currency (id varchar(20),name varchar(30),symbol varchar(20),price varchar(20),change varchar(20))");
NDFsql("INSERT INTO users VALUES ('admin',0,'".MD16("888888")."')");
}

//create();//初次建数据库用的后期用不到
?>