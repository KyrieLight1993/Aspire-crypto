<?php 
if($ndfpage==''){exit;
?>
<link href="styles.css" type="text/css" rel="stylesheet" />
<?php }?>

<div style="background-color:#343028; width:100%; height:auto">
<table width="100%" border="0" align="center" cellpadding="0" cellspacing="0" bgcolor="#343028">
  <tr>
    <td height="30">&nbsp;</td>
  </tr>
  <tr>
    <td height="13"><table width="1250" border="0" align="center" cellpadding="0" cellspacing="20">
      <tr>
        <td width="470" valign="top" class="T150"><span class="Bai Bold">CONTACT US</span><br />
          <a href="about.php" class="home">About Us</a><br />
          <a href="terms.php" class="home">Terms of Use</a><br />
<a href="login.php" class="home Bold">Login/Register</a>
</td>
        <td width="455" valign="top"><br /></td>
        <td width="245" valign="top">
		<span class="Bai Bold">FOLLOW US</span><br />
		<br />
 <a href="https://www.instagram.com/futurestudiescanada/?hl=en" target="_blank" class="home"><img src="imgs/Instagram.png" height="32" />
        Instagram</a><br />
        <a href="https://www.facebook.com/ramnish.futurestudies" target="_blank" class="home"><img src="imgs/Facebook.png" height="32" />
        Facebook</a><br />
        <a href="https://www.linkedin.com/in/ramnish-futurestudies-b173b61b9/" target="_blank" class="home"><img src="imgs/linkedin.png" height="32" />LinkedIn</a><br />
        <a href="https://twitter.com/Futurestudiesc1" target="_blank" class="home"><img src="imgs/twitter.png" height="32" />Twitter        </a>
        <div class="P">
 
  </div></td>
      </tr>
    </table></td>
  </tr>
  <tr>
    <td height="1" background="imgs/dotbot.jpg"><img src="imgs/dotbot.jpg" width="1" height="1" /></td>
  </tr>
  <tr>
    <td height="40"><table width="1230" border="0" align="center" cellpadding="0" cellspacing="5">
      <tr>
        <td height="60" align="center" >Copyright &copy; <?=date("Y",time())?>  All rights reserved. </td>
        </tr>
    </table></td>
  </tr>
</table>
</div>