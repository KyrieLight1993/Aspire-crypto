<?php
require("sql.php");
$a=$_GET["a"];
if($a=="out"){
$_SESSION["user"]="";
$user="";
msg("Logged out!");
}

?>