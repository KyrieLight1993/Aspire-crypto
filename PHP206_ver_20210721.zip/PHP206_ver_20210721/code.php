<?PHP 
session_start(); 
//session_register('SafeCode');
//html_entity_decode() 转换格式
$type = 'gif';
$width= 64;
$height= 24;
header("Content-type: image/".$type);
srand((double)microtime()*1000000);
$randval = randStr(4,"NUMBER");
if($type!='gif' && function_exists('imagecreatetruecolor')){ 
     $im = @imagecreatetruecolor($width,$height);
}else{ 
     $im = @imagecreate($width,$height);
}
     $r = Array(225,211,255,223);
     $g = Array(225,236,237,215);
     $b = Array(225,240,216,225);

     $key = rand(0,3);
  
     $backColor = imagecolorallocate($im,$r[$key],$g[$key],$b[$key]);//第一次调用即为画布设置背景颜色（随机）
	 //@imagesetthickness($im, 1);//设置线宽
     //$borderColor = imagecolorallocate($im, 0, 0, 0);//边框色
     $pointColor = imagecolorallocate($im, rand(160,255), rand(100,170), rand(100,255));//点颜色
     @imageantialias($im,true);//抗锯齿
     @imagefilledrectangle($im, 0, 0, $width - 1, $height - 1, $backColor);//背景位置 填充矩形
     @imagerectangle($im, 0, 0, $width-1, $height-1, $borderColor); //边框位置
	 
for ($i = 0; $i < 3; $i++) {//设置干扰线
    $linecolor = imagecolorallocate($im, mt_rand(50, 200), mt_rand(50, 200), mt_rand(50, 200));
    imageline($im, mt_rand(1, 59), mt_rand(1, 23), mt_rand(1, 59), mt_rand(1, 23), $linecolor);
}
     $stringColor = imagecolorallocate($im,2,18,rand(1,200));

     for($i=0;$i<=50;$i++){ //干扰像素点
           $pointX = rand(2,$width-2);
           $pointY = rand(2,$height-2);
           @imagesetpixel($im, $pointX, $pointY, $pointColor);
		   //@imagesetpixel($im, $pointX+1, $pointY, $pointColor);
     }
     //@imagestring($im,5, rand(5,15), rand(1,8), $randval, $stringColor);//写字：图像、字体大小、X、Y、字符串、颜色
	 @imagettftext($im, 18, rand(-3,8), rand(1,10),22,  $stringColor,realpath("actionj.ttf"), $randval);//用TTF字体写字
     $ImageFun='Image'.$type;//用字符串做函数名 字符串()
     $ImageFun($im);
	 //@imagegif($im);
     @imagedestroy($im);
     $_SESSION['SafeCode'] = $randval;
//产生随机字符串
function randStr($len=6,$format='ALL') { 
           switch($format) { 
                 case 'ALL':
                 $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'; break;
                 case 'CHAR':
                 $chars='ABCDEFGHIJKLMNOPQRSTUVWXYZ'; break;
                 case 'NUMBER':
                 $chars='0123456789'; break;
                 default :
                 $chars='abcdefghijklmnopqrstuvwxyz0123456789'; 
                 break;
           }
     $string="";
     while(strlen($string)<$len)
     $string.=substr($chars,(mt_rand()%strlen($chars)),1);
     return $string;
}
?> 